# Offroad Voertuigen lijst

De lijst hieronder geeft aan welke voertuigen vanuit de gemeente zijn toegestaan om te gebruiken buiten de geasfalteerde wegen, we classificeren dit onder:

| Classificering | Uitleg | Omschrijving |
|:---:|---|---|
|V| Verharde weg | een verharde weg waarbij het wegdek uit asfalt of beton bestaat |
|O| Onverharde weg | een onverhard pad of weg waarbij de ondergrond uit zand bestaat |
|A| Off-Road | De ondergrond waarop wordt gereden bestaat uit gras, zand of modder en er is geen zichtbaar pad of weg aanwezig |

## Overtreding

Bij het rijden met een voertuig op een pad of weg, waarvoor deze niet bedoeld is valt dit onder [Artikel 10 - Deelname aan het verkeer](https://silentsources.github.io/eindhovenapv/apv/) van de APV

## Verharde weg

* Akuma
* KTM Super Duke R 1290
* Suzuki Hayabusa
* Yamaha R6
* Sultan
* Sultan Classic

## Onverharde weg

* Mercedes GLE 450
* Mercedes GLE 53 Coupe
* Mercedes Brabus G800
* Audi SQ7
* Bmw x6
* Porsche Macan
* Porsche Cayenne
* Baller
* Baller Sport
* Bentley bentayga
* Camper
* Maibatsu Mule
* Cliffhanger
* Jeep DemonHawk
* Range Rover Evoque
* Gargoyle
* Gang Burrito
* Burrito
* Gresley
* Lamborghini Urus
* Maserati Levante Novitec
* Range Rover SVR Mansory
* Blazer Sport
* Lada 2107
* Range Rover Velar
* Volkswagen Touareg R50
* Alfa Romeo Stelvio
* Jeep Grand Cherokee SRT8
* Toyota Rav-4
* Volvo XC90 T8
* Sultan RS (Met offroad banden eronder)
* Sultan RS Classic (Met offroad banden eronder)
* Subaru Impreza WRX STI 2012

## Off-Road

* Mercedes G65 6x6 AMG
* Mercedes X Klasse
* Mercedes G65 AMG
* Mercedes Maybach G650 Landaulet
* Mercedes Unimog U5023
* Brabus D35
* Brabus 500 4x4
* Can-Am Maverick
* BMW X5M
* Ford Raptor
* Ford velociaptor 6x6
* Nissan Titan
* Dodge Ram 2500 Hemi
* Dodge Ram 1500 TRX
* Jeep Wrangler
* Trophy Truck
* Manchez
* Quad(Met offroad banden eronder)
* Africat
* BF Benito
* Bf Injection
* Bifta
* Bison
* Bobcat XL
* Brawler
* Riata
* Guardian
* Kamacho
* Sanchez
* Dune Buggy
* Contender
* Blazer
* Rebel
* Sandking
* Jeep Gladiator
* Volkswagen Amarok
* Rebel Raid
* BMW X7
* Ford Bronco Wildtrak
* Range Rover Startech
* Range Rover Vogue
* Hummer H1 Alpha
* Land Rover Defender 110 2021
* Ford F-150 1978
* Aston Martin DBX(Met offroad banden eronder)
* Comet Safari Kerst Editie

Ps. Missen er nog voertuigen of is het onduidelijk graag even een ticket ervoor aanmaken