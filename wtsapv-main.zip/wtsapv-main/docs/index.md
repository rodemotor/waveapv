# Wet- en Regelgeving Wave

Welkom op de pagina voor de Wet- en Regelgeving van Wave!
In het menu aan de linkerkant vind je alle verschillende documenten die betrekking hebben op Wave.

Zorg ervoor, dat je voor je deelneemt aan Wave, kennis hebt genomen van deze regels.

- De Algemene Plaatselijke Verordening bevat alle regels die niet te maken hebben met de testserver (dit zijn zogezegd de "server regels").
- Alle overige documenten zijn specifiek bedoeld voor bepaalde zaken (zoals een weapons waar je kan opzoeken wat de spawn name van een bepaald wapen is).

## Officiële discord servers

Wave heeft verschillende discord servers die zijn goed gekeurd door het bestuur deze zijn:

| Server | Beschrijving | Invite link |
|---|---|:---:|
|Wave Testserver| Main discord server van Wave | [Invite](https://discord.gg/wts) |
|Wave Support| Support discord server van Wave | [Invite](https://discord.gg/AFG9X2Chxw) |
|Wave Onderwereld| Onderwereld discord server van Wave | [Invite](https://discord.gg/h7qK55cDFS) |
