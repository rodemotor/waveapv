# Content creëren op Wave

## Introductie

Dit document is opgesteld om wat duidelijkheid te bieden wat betreft het creëren van content op Wave. Het is uiteraard toegestaan om content te creëren op Wave, echter zijn hier wel regels aan verbonden. Deze regels gelden voor elke speler die content wilt creëren en niet enkel voor de content creators zoals aangewezen in de Wave discord.

## Regels

1. Het is verplicht dat als je live bent, en je deelneemt aan een Discord chat als stafflid, dat je een rood balletje voor jouw naam zet: `:red_circle:`
2. Zorg ervoor dat de mensen met wie je in Discord zit afweten van het feit dat je content creëert.
3. Je bent als content creator een visite kaartje voor Wave. Mochten er dingen gebeuren, laat het ons weten.
4. Doordat je jezelf vrij makkelijk in de picture zet, kunnen wij wat strenger zijn tegen streamers aangezien we live beelden van ze hebben.
5. Mocht je iets zien bij een andere content creator wat je niet bevalt. Spreek dan een stafflid aan.
6. RDM, VDM en dat soort zaken on-stream (ook off-stream natuurlijk) wordt direct bestraft.
7. De naam Wave moet in de titel van de video's of livestreams staan zodat het ook door ons gevonden kan worden.

## Sancties

* Bij het tonen van inhoudelijke informatie op de discord (mededelingen, logs, e.d.) zal er bij de eerste overtreding een straf van de 1e categorie uitgeschreven worden. Bij herhaaldelijke overtreding zal ter beoordeling van een hoger stafflid de straf verhoogd kunnen worden.
