# Douanegebieden binnen Eindhoven

Eindhoven kent enkele douanegebieden. In een risicogebied mag preventief gefouilleerd worden. Dus dat wilt zeggen dat ook voertuigen gecontroleerd mogen worden. Hier onder zijn deze gebieden aangegeven.

De korpsleiding is bevoegd om, in samenspraak met de gemeenteraad van Eindhoven, aanvullende douanegebieden aan te wijzen. Hiervoor gelden dezelfde regels als de normale douanegebieden.

## Kaartweergave

![Kaart met douanegebieden](img/douaneGebieden.webp)